"""
Negative-control suite for AWF Guard (`skill.anti-goodhart-verification@3.7.0-rc.2`).

The v3.7.0-rc.1 force-PASS mutation audit showed that 24 of 55 public gate functions could be replaced by
an always-PASS stub without the self-test noticing, because their self-tests only asserted PASS on good
inputs. Every such gate gets at least one known-wrong implementation here that MUST be rejected, plus the
real-operator fixtures (digital homology, sphere clearance, stacked-director diffraction) shared with the
positive self-test. All checks use explicit `raise AssertionError` so they survive `python -O`.
"""
from __future__ import annotations
import ast
import json
import tempfile
from collections import deque
from pathlib import Path
from typing import Any, Callable, Dict, List, Sequence
import numpy as np
from awf_universal_anti_goodhart_gates import (
    ALLOWED_CODER_TASK_KEYS,
    AntiGoodhartGateError,
    AtomicContractViolationError,
    FORBIDDEN_IN_CODER_CONTEXT,
    GLOBAL_ATOM_REGISTRY,
    InformationBoundaryLeakError,
    MetamorphicRelationSpec,
    QuantityTensor,
    SealedHoldoutCapsule,
    SecondOrderCollusionError,
    StationVerificationSpec,
    TensorSpec,
    TrajectoryFairnessContract,
    analyze_contract_and_docstring_intent,
    analyze_receipt_weakness,
    audit_ast_path,
    audit_benchmark_directory,
    audit_benchmark_hackability,
    audit_engine_self_hosting_integrity,
    audit_outer_glue_and_single_source_ast,
    audit_parameter_update_trajectory,
    audit_spec_integrity,
    check_jaxtyping_shape_contract,
    compute_guardrail_composite_score,
    compute_ncc_test_overlap,
    compute_verifier_safety_and_bestofk_gap,
    evaluate_red_blue_adversarial_audit,
    evaluate_universal_declarative_slots,
    execute_metamorphic_relation_suite,
    extract_stripped_ast_physics_card,
    scan_ast_for_hardcoded_short_loops,
    scan_ast_for_pre_split_preprocessing_leakage,
    scientific_atom,
    score_trial_orthogonal_fairness,
    validate_information_boundary,
    verify_analytic_gradient_finite_difference,
    verify_bipolar_reachability_and_multisource_variance,
    verify_coupled_basis_sign_gauge_and_locality_bounds,
    verify_crosstable_physical_inequality_bounds,
    verify_dual_entry_physics_redteam_audit,
    verify_dynamic_feature_variance_and_noncollinearity,
    verify_euler_poincare_and_digital_duality,
    verify_filtration_monotonicity_and_heterogeneous_radius_clearance,
    verify_loocv_generalization_and_train_eval_parity,
    verify_mesh_refinement_invariance_and_noise_floor,
    verify_nonorthogonal_pencil_gauge_and_spectral_parity,
    verify_pairwise_no_self_interaction_and_symmetry,
    verify_physical_matrix_invariants_and_unit_homogeneity,
    verify_pure_input_immutability_and_contracts,
    verify_remediation_closed_loop_and_pareto_candidates,
    verify_rp2_director_gauge_and_reciprocal_conjugacy,
    verify_scale_homogeneity_and_rank1_null_calibration,
    verify_subfragment_spin_and_siteslip_sensitivity,
    verify_unitcell_cyclic_shift_and_chain_convergence,
    verify_verity_receipt_payload,
    verify_weighted_dispersion_kish_and_scale_invariance,
)
from awf_guard_selftests.geometry_fixtures import _OFFSETS_26, _OFFSETS_6, _component_labels, _euler_characteristic_6_complex, _stack_observables, _void_spectrum, digital_homology_betti_chi, sphere_clearance_exact, sphere_clearance_specs, stack_diffraction_exact, stack_diffraction_specs

def digital_homology_6_6_bug(g: np.ndarray) -> np.ndarray:
    return digital_homology_betti_chi(g, background_offsets=tuple(_OFFSETS_6))

def sphere_clearance_nearest_center_bug(points: np.ndarray, centers: np.ndarray, radii: np.ndarray, c_min: float) -> np.ndarray:
    raw = np.linalg.norm(points[:, None, :] - centers[None, :, :], axis=2)
    idx = np.argmin(raw, axis=1)
    return _void_spectrum(raw[np.arange(len(points)), idx] - radii[idx], c_min)

def stack_diffraction_center_to_center_bug(centers: np.ndarray, sub_normals: np.ndarray) -> np.ndarray:
    n_hat = sub_normals / np.linalg.norm(sub_normals, axis=1, keepdims=True)
    d_c = float(np.mean(np.linalg.norm(np.diff(centers, axis=0), axis=1)))
    return _stack_observables(d_c, n_hat, float(np.mean(np.abs(n_hat[:, 2]))))

def stack_diffraction_sign_sensitive_bug(centers: np.ndarray, sub_normals: np.ndarray) -> np.ndarray:
    n_hat = sub_normals / np.linalg.norm(sub_normals, axis=1, keepdims=True)
    d_perp = float(np.mean(np.abs(np.sum(np.diff(centers, axis=0) * n_hat[:-1], axis=1))))
    return _stack_observables(d_perp, n_hat, float(np.mean(n_hat[:, 2])))

def _gate_fail_issue(label: str, result: Dict[str, Any], needle: str) -> str:
    """Return "" when `result` is a non-PASS verdict whose diagnostics mention `needle`, else a diagnostic."""
    payload = result.get('violations') or result.get('pair_regression_violations') or result.get('matrix_violations') or result
    text = json.dumps(payload, default=str)
    if result.get('status') == 'PASS' or (needle and needle not in text):
        return f"[{label}] expected FAIL mentioning `{needle}`, got status={result.get('status')}: {text[:240]}"
    return ''

def _raises_issue(label: str, fn: Callable[[], Any], exc_type: type, needle: str) -> str:
    try:
        fn()
    except exc_type as exc:
        return '' if needle in str(exc) else f'[{label}] raised but message lacks `{needle}`: {exc}'
    return f'[{label}] expected {exc_type.__name__} containing `{needle}`, but call returned normally'

def _kish_dispersion(vals: np.ndarray, weights: np.ndarray) -> np.ndarray:
    wn = weights / float(np.sum(weights))
    mu = float(np.sum(wn * vals))
    eff_n = 1.0 / float(np.sum(wn ** 2))
    sd = float(np.sqrt(float(np.sum(wn * (vals - mu) ** 2)) * (eff_n / (eff_n - 1.0))))
    g_raw = sd / mu * 100.0
    return np.array([mu, sd, g_raw, g_raw / float(np.sqrt(2.0 * np.pi))], dtype=np.float64)

def _coupled_sr_fixture(full_system: bool, coherent: bool) -> Callable[..., np.ndarray]:
    sl = slice(0, 4) if full_system else slice(0, 2)

    def sr_operator(h_ex_ev: np.ndarray, mu_vecs_debye: np.ndarray, coords_ang: np.ndarray) -> np.ndarray:
        _, evecs = np.linalg.eigh(h_ex_ev[sl, sl])
        c0 = evecs[:, 0]
        p0 = c0 ** 2
        pr0 = 1.0 / float(np.sum(p0 ** 2))
        incoh = float(p0 @ np.sum(mu_vecs_debye[sl] ** 2, axis=1))
        m_sq = float(np.sum((c0 @ mu_vecs_debye[sl]) ** 2)) if coherent else incoh
        eta = m_sq / max(incoh, 1e-12)
        r_mean = p0 @ coords_ang[sl]
        rg = float(np.sqrt(max(float(p0 @ np.sum((coords_ang[sl] - r_mean) ** 2, axis=1)), 0.0)))
        return np.array([pr0, pr0, eta, 0.85 * eta, eta, rg], dtype=np.float64)
    return sr_operator

def coupled_sr_inputs() -> Dict[str, np.ndarray]:
    h_sr = np.array([[1.8, -0.04, 1e-05, 0.0], [-0.04, 1.8, 0.0, 1e-05], [1e-05, 0.0, 1.8, -0.04], [0.0, 1e-05, -0.04, 1.8]])
    mu_sr = np.tile(np.array([[10.0, 0.0, 0.0]]), (4, 1))
    c_sr1 = np.array([[0.0, 0.0, 0.0], [4.0, 0.0, 0.0], [40.0, 0.0, 0.0], [44.0, 0.0, 0.0]])
    c_sr2 = np.array([[0.0, 0.0, 0.0], [4.0, 0.0, 0.0], [90.0, 0.0, 0.0], [94.0, 0.0, 0.0]])
    return {'h': h_sr, 'mu': mu_sr, 'c1': c_sr1, 'c2': c_sr2}

def _verify_negative_pairwise_loocv_scale() -> int:
    """G5o / G7i / G3j: asymmetric kernels, intra-group leakage, over-fit LOOCV, train/eval skew, biases, null drift."""
    pts_a = np.array([[0.0, 0.0, 0.0], [1.0, 0.0, 0.0]])
    pts_b = np.array([[0.0, 0.0, 3.0], [1.0, 0.0, 3.0]])

    def sym_kernel(pa: np.ndarray, pb: np.ndarray) -> float:
        return float(np.exp(-np.linalg.norm(np.mean(pa, axis=0) - np.mean(pb, axis=0))))

    def leaky_aggregator(groups: List[np.ndarray], gids: List[int]) -> float:
        return float(sum((sym_kernel(groups[i], groups[j]) for i in range(len(groups)) for j in range(i + 1, len(groups)))))
    rng = np.random.default_rng(7)
    x_good = np.array([[1.0], [2.0], [3.0], [4.0], [5.0], [6.0]])
    y_good = np.array([2.1, 3.9, 6.1, 8.0, 9.9, 12.1])
    centered_svd = lambda m: float(np.linalg.svd(m - np.outer(np.mean(m, axis=1), np.ones(m.shape[1])), compute_uv=False)[0])
    issues = [_gate_fail_issue('G5o asymmetric kernel', verify_pairwise_no_self_interaction_and_symmetry(lambda pa, pb: float(np.sum(pa) - 2.0 * np.sum(pb)), pts_a, pts_b), 'exchange symmetry'), _gate_fail_issue('G5o intra-group leakage', verify_pairwise_no_self_interaction_and_symmetry(sym_kernel, pts_a, pts_b, grouped_aggregator_fn=leaky_aggregator), 'Intra-group'), _gate_fail_issue('G7i over-fit noise regression', verify_loocv_generalization_and_train_eval_parity(rng.normal(size=(6, 5)), rng.normal(size=6)), 'LOOCV'), _gate_fail_issue('G7i train/eval skew', verify_loocv_generalization_and_train_eval_parity(x_good, y_good, calibrate_feature_fn=lambda arr: arr * 2.0, eval_feature_fn=lambda arr: arr * 2.0 + 0.001, parity_test_inputs=[np.array([1.0, 2.0])]), 'skew'), _gate_fail_issue('G3j additive bias', verify_scale_homogeneity_and_rank1_null_calibration(lambda m: centered_svd(m) + 0.1, np.array([[1.0, -1.0], [-1.0, 1.0]]), homogeneity_degree=1.0), 'homogeneity'), _gate_fail_issue('G3j uncalibrated rank-1 null', verify_scale_homogeneity_and_rank1_null_calibration(lambda m: float(np.max(m)), np.array([[1.0, 2.0], [3.0, 4.0]]), homogeneity_degree=1.0, rank1_null_input_builder_fn=lambda p: np.outer(np.full(6, p), np.ones(6)), null_metric_extractor_fn=lambda val: float(val)), 'rank-1')]
    bad = [msg for msg in issues if msg]
    if bad:
        raise AssertionError('Negative controls (G5o/G7i/G3j) not rejected:\n' + '\n'.join(bad))
    return len(issues)

def _verify_negative_remediation_bipolar_mesh() -> int:
    """G6p / G5p / G1e: watered-down fixes, oracle-failing candidates, non-negative surrogates, extensive drift."""
    pre_src = "def f(d, x):\n    if x > 3:\n        return d['a'] * x\n    if x > 2:\n        return d['b'] * x\n    if x > 1:\n        return d['c'] * x\n    if x > 0:\n        return d['d'] * x\n    return -d['a'] * x\n"
    collapsed_src = "def f(d, x):\n    return d['a'] * x\n"
    evals = [{'x': np.array([1.0, 2.0])}, {'x': np.array([3.0, 4.0])}]
    good = {'cand_best': lambda x: x * 2.0}
    g6p_collapse = verify_remediation_closed_loop_and_pareto_candidates(pre_src, collapsed_src, good, lambda x: x * 2.0, evals)
    g6p_wrong = verify_remediation_closed_loop_and_pareto_candidates(pre_src, pre_src, {'bad': lambda x: x + 1.0}, lambda x: x * 2.0, evals)
    g6p_loosen = verify_remediation_closed_loop_and_pareto_candidates(pre_src, pre_src, good, lambda x: x * 2.0, evals, tolerance_loosened=True)

    def ramp_builder(n_g: int) -> Dict[str, Any]:
        return {'grid': np.tile(np.linspace(0.0, 1.0, n_g)[:, None], (1, n_g)), 'h': 4.0 / float(n_g)}

    def minmax_integral(grid: np.ndarray, h: float) -> float:
        return float(np.sum((grid - grid.min()) / (np.ptp(grid) + 1e-300)) * h ** 2)
    noisy = np.ones((16, 16)) + 1e-08 * np.random.default_rng(3).normal(size=(16, 16))
    issues = [_gate_fail_issue('G6p complexity collapse', g6p_collapse, 'ComplexityCollapse'), '' if g6p_wrong['status'] != 'PASS' and g6p_wrong['selected_pareto_candidate'] is None else '[G6p oracle-failing candidate accepted]', '' if g6p_loosen['status'] == 'ESCALATE_TO_HUMAN' else '[G6p tolerance loosening not escalated]', _gate_fail_issue('G5p non-negative surrogate', verify_bipolar_reachability_and_multisource_variance(lambda x: float(x) ** 2, -2.5, 3.2), 'negative-regime'), _gate_fail_issue('G5p single-source variance', verify_bipolar_reachability_and_multisource_variance(lambda x: float(x), -2.5, 3.2, variance_propagator_fn=lambda v_obs, means, v_ref: float(v_obs), baseline_fn=lambda theta: float(0.5 * theta[0] + 0.5 * theta[1])), 'Single-source'), _gate_fail_issue('G1e extensive voxel-count drift', verify_mesh_refinement_invariance_and_noise_floor(lambda grid, h: float(np.sum(grid)), ramp_builder, max_refinement_rel_drift=1e-06), 'Mesh-refinement'), _gate_fail_issue('G1e min-max noise stretching', verify_mesh_refinement_invariance_and_noise_floor(minmax_integral, ramp_builder, max_refinement_rel_drift=0.2, noisy_null_input_kwargs={'grid': noisy, 'h': 0.25}, expected_null_output=0.0), 'noise-floor')]
    bad = [msg for msg in issues if msg]
    if bad:
        raise AssertionError('Negative controls (G6p/G5p/G1e) not rejected:\n' + '\n'.join(bad))
    return len(issues)

def _verify_negative_topology_clearance_director() -> int:
    """G5q / G5r / G3k: (6,6) adjacency bug, memorized homology, k=1 center trap, slip inflation, vacuous probes."""
    shell = np.zeros((5, 5, 5))
    shell[1:4, 1:4, 1:4] = 1.0
    shell[2, 2, 2] = 0.0
    punct = shell.copy()
    punct[1, 1, 1] = 0.0
    curve = np.zeros((5, 5, 5))
    curve[1:4, 2, 2] = 1.0
    table = {'s': [1.0, 0.0, 1.0, 2.0], 'p': [1.0, 0.0, 0.0, 1.0], 'c': [1.0, 0.0, 0.0, 1.0]}
    sum_memorizer = lambda g: np.array([1.0, 0.0, 1.0, 2.0]) if float(np.sum(g)) == 26.0 else np.array([1.0, 0.0, 0.0, 1.0])
    clr = sphere_clearance_specs()
    stk = stack_diffraction_specs()
    g3k = verify_rp2_director_gauge_and_reciprocal_conjugacy
    issues = [_gate_fail_issue('G5q (6,6) adjacency bug', verify_euler_poincare_and_digital_duality(digital_homology_6_6_bug, {'g': shell}, {'g': punct}, {'g': curve}), 'homology mismatch'), _gate_fail_issue('G5q label lookup table', verify_euler_poincare_and_digital_duality(lambda tag: np.array(table[tag]), {'tag': 's'}, {'tag': 'p'}, {'tag': 'c'}), '3-D ndarray'), _gate_fail_issue('G5q voxel-sum memorizer', verify_euler_poincare_and_digital_duality(sum_memorizer, {'g': shell}, {'g': punct}, {'g': curve}), 'Gate-generated'), _gate_fail_issue('G5r k=1 nearest-center trap', verify_filtration_monotonicity_and_heterogeneous_radius_clearance(sphere_clearance_nearest_center_bug, clr['base'], clr['probe']), 'Heterogeneous-radius'), _gate_fail_issue('G5r vacuous probe', verify_filtration_monotonicity_and_heterogeneous_radius_clearance(sphere_clearance_exact, clr['base'], dict(clr['base'])), 'Vacuous probe'), _gate_fail_issue('G3k center-to-center slip inflation', g3k(stack_diffraction_center_to_center_bug, stk['base'], slipped_stack_kwargs=stk['slipped'], short_stack_kwargs=stk['short']), 'Lateral-slip'), _gate_fail_issue('G3k director sign sensitivity', g3k(stack_diffraction_sign_sensitive_bug, stk['base'], slipped_stack_kwargs=stk['slipped'], short_stack_kwargs=stk['short']), 'headless-director'), _gate_fail_issue('G3k slipped probe equals base', g3k(stack_diffraction_center_to_center_bug, stk['base'], slipped_stack_kwargs=dict(stk['base']), short_stack_kwargs=stk['short']), 'Vacuous probe'), _gate_fail_issue('G3k probes omitted', g3k(stack_diffraction_center_to_center_bug, stk['base']), 'Required probe')]
    bad = [msg for msg in issues if msg]
    if bad:
        raise AssertionError('Negative controls (G5q/G5r/G3k) not rejected:\n' + '\n'.join(bad))
    return len(issues)

def _verify_negative_dispersion_pencil_coupled() -> int:
    """G5s / G5t / G3l: unweighted dispersion, missing Lowdin S^-1/2, incoherent sums, cross-cluster delocalization."""
    vals = np.array([3.45, 3.5, 3.55, 3.6])
    base_w = {'vals': vals, 'weights': np.ones(4)}
    padded = {'vals': np.append(vals, [25.0, 50.0]), 'weights': np.array([1.0, 1.0, 1.0, 1.0, 0.0, 0.0])}
    s_toy = np.array([[1.0, 0.0, 0.05, -0.02], [0.0, 1.0, 0.03, 0.04], [0.05, 0.03, 1.0, 0.0], [-0.02, 0.04, 0.0, 1.0]])
    f_toy = np.array([[-8.0, 0.0, 0.12, -0.08], [0.0, -7.5, 0.09, 0.15], [0.12, 0.09, -8.0, 0.0], [-0.08, 0.15, 0.0, -7.5]])
    j_toy = np.array([[-0.02, 0.0], [0.0, -0.01]])

    def no_lowdin_diabat(s_mat: np.ndarray, f_mat: np.ndarray, j_coul: np.ndarray) -> np.ndarray:
        t_sub = f_mat[0:2, 2:4]
        j_val = float(j_coul[0, 0]) * 1000.0
        return np.array([abs(float(t_sub[1, 1])), float(np.linalg.norm(t_sub)), 0.1, 0.25, j_val, -j_val])
    sr = coupled_sr_inputs()
    sr_base = {'h_ex_ev': sr['h'], 'mu_vecs_debye': sr['mu'], 'coords_ang': sr['c1']}
    sr_far = {'h_ex_ev': sr['h'], 'mu_vecs_debye': sr['mu'], 'coords_ang': sr['c2']}
    g3l = verify_coupled_basis_sign_gauge_and_locality_bounds
    issues = [_gate_fail_issue('G5s unweighted dispersion', verify_weighted_dispersion_kish_and_scale_invariance(lambda vals, weights: _kish_dispersion(vals, np.ones_like(vals)), base_w, 'vals', zero_weight_padded_kwargs=padded), 'Zero-weight'), _gate_fail_issue('G5t missing Lowdin orthogonalization', verify_nonorthogonal_pencil_gauge_and_spectral_parity(no_lowdin_diabat, {'s_mat': s_toy, 'f_mat': f_toy, 'j_coul': j_toy}, (('f_mat', 's_mat'),)), 'metric-shift'), _gate_fail_issue('G3l incoherent sum', g3l(_coupled_sr_fixture(False, False), sr_base, separated_cluster_shifted_kwargs=sr_far, max_cluster_size=2), 'Insensitive'), _gate_fail_issue('G3l cross-cluster delocalization', g3l(_coupled_sr_fixture(True, True), sr_base, separated_cluster_shifted_kwargs=sr_far, max_cluster_size=2), ''), _gate_fail_issue('G3l vacuous locality probe', g3l(_coupled_sr_fixture(False, True), sr_base, separated_cluster_shifted_kwargs=dict(sr_base), max_cluster_size=2), 'Vacuous probe')]
    bad = [msg for msg in issues if msg]
    if bad:
        raise AssertionError('Negative controls (G5s/G5t/G3l) not rejected:\n' + '\n'.join(bad))
    return len(issues)

def _verify_negative_declarative_slots() -> int:
    """S1.1 / S3.1 / S5.1 declarative injector: empty, diluted, identity, tautological and wrong laws."""

    def wrong_parity(x: np.ndarray) -> np.ndarray:
        return np.asarray(x) + 1.0
    base = {'x': np.array([1.0, 2.0])}
    flip = {'x': np.array([-1.0, -2.0])}
    ev = evaluate_universal_declarative_slots
    eq = lambda **kw: {'s3_1_equivariance_laws': [dict({'name': 'parity', 'transformed_kwargs': flip}, **kw)]}
    issues = [_gate_fail_issue('Decl empty laws', ev(wrong_parity, base, {}), 'nothing was verified'), _gate_fail_issue('Decl wrong invariance', ev(wrong_parity, base, eq()), 'EquivarianceLaw'), _gate_fail_issue('Decl tol dilution', ev(wrong_parity, base, eq(tol=1000000000.0)), 'hard ceiling'), _gate_fail_issue('Decl vacuous sensitivity floor', ev(wrong_parity, base, eq(mode='sensitivity', tol=0.0)), 'Sensitivity floor'), _gate_fail_issue('Decl identity transform', ev(wrong_parity, base, {'s3_1_equivariance_laws': [{'name': 'id', 'transformed_kwargs': dict(base)}]}), 'identity transform'), _gate_fail_issue('Decl tautological predicate', ev(wrong_parity, base, {'s1_1_regime_probes': [{'name': 'p', 'input_kwargs': flip, 'predicate_fn': lambda out: True}]}), 'tautological predicate'), _gate_fail_issue('Decl NaN-swallowing residual', ev(wrong_parity, base, {'s5_1_manifold_laws': [{'name': 'bound', 'residual_fn': lambda out: max(0.0, float(out[0]) - 5.0), 'tol': 1e-09}]}), 'tautological residual')]
    bad = [msg for msg in issues if msg]
    if bad:
        raise AssertionError('Negative controls (declarative slots) not rejected:\n' + '\n'.join(bad))
    return len(issues)

def _write_long_function_source(n_body_lines: int) -> str:
    body = ''.join((f'    acc = acc + x * {i + 2}\n' for i in range(n_body_lines)))
    return 'def long_kernel(x):\n    acc = x\n' + body + '    return acc\n'

def _verify_negative_meta_and_static_gates() -> int:
    """Self-audit, Meta-Guard spec integrity, AST path, BenchJack directory, trajectory, loop, leakage, Verity."""

    def kernel(x: np.ndarray) -> np.ndarray:
        return x * 2.0
    spec_collusive = StationVerificationSpec(station_id='NC-1', station_name='collusive', target_fn=kernel, tier=2, orthogonal_oracle_fn=kernel, small_input_kwargs={'x': np.ones(3)})
    spec_diluted = StationVerificationSpec(station_id='NC-2', station_name='diluted', target_fn=kernel, tier=1, limit_tol=1.0)
    frozen = np.zeros((6, 4))
    frozen[:, 0] = np.arange(6, dtype=np.float64)
    with tempfile.TemporaryDirectory(prefix='ag_negctl_') as tmp:
        root = Path(tmp)
        (root / 'bad_engine.py').write_text('def f(x):\n    # TODO finish this\n    return x\n\n\n' + _write_long_function_source(201), encoding='utf-8')
        (root / 'bench').mkdir()
        (root / 'bench' / 'evaluate.py').write_text('def evaluate(pred, gold):\n    try:\n        return float(pred == gold)\n    except Exception:\n        return 1.0\n', encoding='utf-8')
        (root / 'nan_mask.py').write_text('import numpy as np\n\ndef f(x):\n    return np.nan_to_num(x)\n', encoding='utf-8')
        self_audit = audit_engine_self_hosting_integrity(root / 'bad_engine.py', max_fn_lines=200)
        bench = audit_benchmark_directory(root / 'bench')
        ast_res = audit_ast_path(root / 'nan_mask.py')
    issues = ['' if self_audit['status'] == 'FAIL' and self_audit['oversized_functions'] and (self_audit['g5n_finding_count'] > 0) else f'[Self-audit accepted TODO + over-200-line function] {self_audit}', '' if bench['status'] == 'FAIL' else f'[BenchJack directory accepted except->1.0 evaluator] {bench}', _gate_fail_issue('AST path nan_to_num', ast_res, 'nan_to_num'), _raises_issue('Meta-Guard collusive oracle', lambda: audit_spec_integrity(spec_collusive), SecondOrderCollusionError, 'Collusive'), _raises_issue('Meta-Guard threshold dilution', lambda: audit_spec_integrity(spec_diluted), SecondOrderCollusionError, 'Dilution'), _raises_issue('Frozen-DoF trajectory', lambda: audit_parameter_update_trajectory(frozen, 4), AntiGoodhartGateError, 'Frozen-DoF'), _raises_issue('Short loop', lambda: scan_ast_for_hardcoded_short_loops('for it in range(3):\n    x = it\n'), AntiGoodhartGateError, 'Loop-Truncation'), '' if scan_ast_for_pre_split_preprocessing_leakage('scaler.fit(X)\nX_tr, X_te = train_test_split(X)\n') else '[Pre-split fit before train_test_split not detected]', '' if verify_verity_receipt_payload('{not json')['accepted'] is False else '[Verity accepted malformed JSON]', '' if verify_verity_receipt_payload({'schema': 'wrong.v0', 'accepted': True})['accepted'] is False else '[Verity accepted wrong schema]']
    bad = [msg for msg in issues if msg]
    if bad:
        raise AssertionError('Negative controls (meta/static) not rejected:\n' + '\n'.join(bad))
    return len(issues)

def _verify_negative_rc8_scientific_and_contracts() -> int:
    """rc.8 regressions: SealedHoldoutCapsule vault/cap, bare-array unit rejection, G2b/G5m/G5q/G5s/G3g."""
    cap = SealedHoldoutCapsule(metric_name='energy_gap', secret_target=1.25, secret_tol=0.01)
    cap_vars = vars(cap)
    for q in (1.0, 2.0, 3.0):
        cap.evaluate_blind(q)
    temp_atom_id = 'ATOM-NC-UNIT-GUARD'
    try:
        @scientific_atom(
            atom_id=temp_atom_id,
            tutor_station='ST-NC',
            math_contract='out = 2 * e',
            inputs={'e': TensorSpec(shape=('N',), unit='eV')},
            outputs={'out': TensorSpec(shape=('N',), unit='eV')},
        )
        def _unit_guarded_atom(e: np.ndarray) -> QuantityTensor:
            return QuantityTensor(e * 2.0, unit='eV')
        unit_issue = _raises_issue('TensorSpec bare ndarray unit rejection', lambda: _unit_guarded_atom(np.ones(2)), AtomicContractViolationError, 'QuantityTensor')
    finally:
        GLOBAL_ATOM_REGISTRY.pop(temp_atom_id, None)
    shell = np.zeros((7, 7, 7))
    shell[2:5, 2:5, 2:5] = 1.0
    shell[3, 3, 3] = 0.0
    punct = shell.copy()
    punct[2, 2, 2] = 0.0
    shape_sum_cheat = lambda g: np.array([1.0, 0.0, 1.0, 2.0]) if int(np.sum(g)) == (6 * (g.shape[0] - 4) ** 2 - 12 * (g.shape[0] - 4) + 8) else np.array([1.0, 0.0, 0.0, 1.0])
    vals = np.array([3.45, 3.5, 3.55, 3.6])
    base_w = {'vals': vals, 'weights': np.ones(4)}
    padded = {'vals': np.append(vals, [25.0, 50.0]), 'weights': np.array([1.0, 1.0, 1.0, 1.0, 0.0, 0.0])}

    def unweighted_bessel_cheat(vals: np.ndarray, weights: np.ndarray) -> np.ndarray:
        pos = vals[weights > 0]
        mu = float(np.average(vals, weights=weights))
        sd = float(np.std(pos, ddof=1))
        g_raw = sd / mu * 100.0
        return np.array([mu, sd, g_raw, g_raw / float(np.sqrt(2.0 * np.pi))], dtype=np.float64)

    def sneaky_tail_mutator(payload: Dict[str, Any]) -> float:
        payload['arr'][1500] = 9.0
        return float(payload['arr'][0])

    dbc_res = verify_pure_input_immutability_and_contracts(sneaky_tail_mutator, {'payload': {'arr': np.ones(2000)}})
    issues = [
        '' if 'secret_target' not in cap_vars and 'target' not in cap_vars else f'[Capsule leaked attributes in vars()] {cap_vars}',
        _raises_issue('Capsule negative/zero tol', lambda: SealedHoldoutCapsule('m', 1.0, 0.0), ValueError, 'positive'),
        _raises_issue('Capsule query budget cap', lambda: cap.evaluate_blind(4.0), AntiGoodhartGateError, 'Query-Budget'),
        unit_issue,
        _gate_fail_issue('G2b flat-point zero gradient collapse', verify_analytic_gradient_finite_difference(lambda r: float(np.sum(r ** 4)), lambda r: np.zeros_like(r), {'r': np.zeros(2)}, is_negative_gradient=False), ''),
        _gate_fail_issue('G5m complex anti-Hermitian matrix', verify_physical_matrix_invariants_and_unit_homogeneity(matrix=np.array([[1.0, 2.0j], [2.0j, 1.0]], dtype=np.complex128), atom_registry={}), 'Hermiticity'),
        _gate_fail_issue('G5q 26-voxel shape+sum memorizer', verify_euler_poincare_and_digital_duality(shape_sum_cheat, {'g': shell}, {'g': punct}), 'punct_tab_even'),
        _gate_fail_issue('G5s unweighted ddof=1 Kish cheat', verify_weighted_dispersion_kish_and_scale_invariance(unweighted_bessel_cheat, base_w, 'vals', zero_weight_padded_kwargs=padded), 'Kish'),
        '' if dbc_res.get('status') == 'FAIL' and dbc_res.get('mutated_inputs') == ['primary:payload'] else f'[G3g missed tail index 1500 mutation] {dbc_res}',
    ]
    bad = [msg for msg in issues if msg]
    if bad:
        raise AssertionError('Negative controls (rc8 scientific/contracts) not rejected:\n' + '\n'.join(bad))
    return len(issues)


def _verify_negative_rc8_nonprefix_gates() -> int:
    """Dedicated negative controls for all 9 non-prefix verdict/scoring functions."""
    mr_bad = MetamorphicRelationSpec(
        mr_id='broken_additivity',
        data=[1.0, 2.0],
        transform_fn=lambda x: x + 1.0,
        relation_fn=lambda s_out, f_out: False,
    )
    intent_tree = ast.parse('def compute_entropy(x):\n    """Compute log(x) of input."""\n    return x + 1.0\n')
    intent_v = analyze_contract_and_docstring_intent(intent_tree)
    weak_reason = analyze_receipt_weakness('pytest -k test_easy_only', '1 passed in 0.01s')
    test_blob = "EXPECTED_MAGIC_VECTOR = [0.142857142857, 0.285714285714, 0.428571428571, 0.571428571428, 0.714285714285, 0.857142857142]\n" * 3
    ncc_bad = compute_ncc_test_overlap('def cheat():\n    ' + test_blob + '    return EXPECTED_MAGIC_VECTOR\n', test_blob)
    gr_bad = compute_guardrail_composite_score([{'severity': 'error', 'category': 'scope', 'detail': 'out of scope'}])
    contract = TrajectoryFairnessContract(forbidden_paths=('secret_answers.json',))
    unfair_score = score_trial_orthogonal_fairness(1.0, [{'tool': 'read_file', 'command': 'cat secret_answers.json', 'output': 'ans=42'}], contract, 'return 42')
    issues = [
        _raises_issue('Metamorphic broken relation', lambda: execute_metamorphic_relation_suite(lambda x: x * 2.0, [mr_bad]), AntiGoodhartGateError, 'broken_additivity'),
        _raises_issue('Jaxtyping variadic mismatch', lambda: check_jaxtyping_shape_contract('y', (4, 3), ('*batch', 3), {}, {'batch': (True, (2,))}), AtomicContractViolationError, 'Variadic'),
        _raises_issue('Nested forbidden key leak', lambda: validate_information_boundary({'inputs_contract': {'holdout_secret_target': 1.0}}, set(ALLOWED_CODER_TASK_KEYS), set(FORBIDDEN_IN_CODER_CONTEXT), 'test_boundary'), InformationBoundaryLeakError, 'holdout_secret_target'),
        '' if len(intent_v) > 0 else '[Intent analyzer missed missing log in log(x) docstring]',
        '' if isinstance(weak_reason, str) and 'narrowed' in weak_reason else f'[Receipt weakness missed -k scope narrowing] {weak_reason}',
        '' if ncc_bad.get('applicable') is True and ncc_bad.get('passed') is False else f'[NCC overlap missed verbatim test literal paste] {ncc_bad}',
        _raises_issue('Empty rollouts verifier safety', lambda: compute_verifier_safety_and_bestofk_gap([]), ValueError, 'non-empty'),
        '' if gr_bad.get('verdict') == 'blocked' and gr_bad.get('has_errors') is True else f'[Guardrail composite score accepted error finding] {gr_bad}',
        '' if unfair_score.fairness == 0 and unfair_score.solved_fairly == 0.0 else f'[Orthogonal fairness accepted secret read] {unfair_score}',
    ]
    bad = [msg for msg in issues if msg]
    if bad:
        raise AssertionError('Negative controls (rc8 non-prefix gates) not rejected:\n' + '\n'.join(bad))
    return len(issues)


def _verify_negative_rc38_physics_redteam_and_glue() -> int:
    """G4d / G3m / G1f / G5u / G6q / G7j: frozen column, spin/slip blindness, cyclic asymmetry, Voc violation, outer glue, forged redteam."""
    frozen_mat = np.array([[8.32, 0.2], [8.35, 0.3], [8.34, 0.4], [8.37, 0.1], [8.33, 0.5]], dtype=np.float64)
    collinear_mat = np.array([[1.0, 2.001], [2.0, 3.998], [3.0, 6.002], [4.0, 7.999], [5.0, 10.001]], dtype=np.float64)
    fa = np.array([[0.0, 0.0, 0.0], [1.4, 0.0, 0.0], [2.2, 0.5, 0.0]], dtype=np.float64)
    fb = np.array([[4.5, 0.0, 0.0], [5.8, 0.6, 0.2], [6.5, -0.4, 0.1]], dtype=np.float64)
    win = np.array([1.2, 0.7, 1.8, 0.9], dtype=np.float64)
    non_periodic_obs = lambda w: float(np.sum(np.asarray(w, dtype=np.float64)[:-1] * np.asarray(w, dtype=np.float64)[1:]))
    bloated_glue = (
        "def assemble_physics_outer(arr, cfg):\n"
        "    scale = cfg.get('eps', 3.5)\n"
        + "    arr = arr * 1.0 + 0.0\n" * 36
        + "    return float(np.sum(arr)) * scale\n"
    )
    divergent_companion = "def assemble_physics_outer(arr, cfg):\n    return float(np.mean(arr))\n"
    lying_src = (
        "def compute_field(r_com):\n"
        "    \"\"\"Computes anisotropic_multipole coupling on sub-rings.\"\"\"\n"
        "    # isotropic point-charge shortcut ignores sub-rings\n"
        "    return 1.0 / r_com\n"
    )
    stripped_card = extract_stripped_ast_physics_card(lying_src)
    issues = [
        _gate_fail_issue('G4d frozen centroid column', verify_dynamic_feature_variance_and_noncollinearity(frozen_mat, ['d_ct', 'solv']), 'frozen'),
        _gate_fail_issue('G4d collinear feature pair', verify_dynamic_feature_variance_and_noncollinearity(collinear_mat, ['f1', 'f2']), 'collinear'),
        _gate_fail_issue('G3m center-distance-only blind model', verify_subfragment_spin_and_siteslip_sensitivity(lambda a, b: 1.0 / float(np.linalg.norm(np.mean(b, axis=0) - np.mean(a, axis=0))), fa, fb), 'spin'),
        _gate_fail_issue('G1f open-boundary cyclic-shift drift', verify_unitcell_cyclic_shift_and_chain_convergence(non_periodic_obs, [win, np.roll(win, 1)], [win[::-1]], [1, 2, 3], [0.5, 0.7, 1.1]), 'cyclic'),
        _gate_fail_issue('G5u violated Voc detailed-balance bound', verify_crosstable_physical_inequality_bounds({'G_CT': 0.899, 'qVoc': 0.912, 'dE1': 0.24, 'dE3': 0.22}, [{'bound_id': 'Voc_bound', 'lhs_terms': {'G_CT': 1.0}, 'rhs_terms': {'qVoc': 1.0, 'dE1': 1.0, 'dE3': 1.0}, 'relation': '>=', 'slack_tol': 1e-3}]), 'inequality'),
        _gate_fail_issue('G6q bloated outer glue and duplicate', audit_outer_glue_and_single_source_ast(bloated_glue, companion_sources={'other.py': divergent_companion}), 'outer-glue'),
        _gate_fail_issue('G7j forged retroactive pre_code', verify_dual_entry_physics_redteam_audit({'mode': 'pre_code', 'author_id': 'a', 'reviewer_id': 'b', 'pre_existing_code_present': True, 'design_timestamp_epoch': 100.0, 'implementation_start_epoch': 200.0, 'critique_axes_checked': ['sub_fragment_symmetry_and_multipole', 'periodic_boundary_and_size_convergence', 'functional_environment_and_thermodynamic_bounds', 'cross_station_shared_observable_lock'], 'approximation_ledger': [{'assumption': 'x'}], 'identified_risks_and_remediations': [{'risk': 'r1', 'remediation_or_gate': 'g1', 'resolved': True}, {'risk': 'r2', 'remediation_or_gate': 'g2', 'resolved': True}]}), 'retroactive'),
        _gate_fail_issue('G7j docstring-only claim mismatch', verify_dual_entry_physics_redteam_audit({'mode': 'post_hoc_audit', 'author_id': 'a', 'reviewer_id': 'b', 'critique_axes_checked': ['sub_fragment_symmetry_and_multipole', 'periodic_boundary_and_size_convergence', 'functional_environment_and_thermodynamic_bounds', 'cross_station_shared_observable_lock'], 'identified_risks_and_remediations': [{'risk': 'r1', 'remediation_or_gate': 'g1', 'resolved': True}, {'risk': 'r2', 'remediation_or_gate': 'g2', 'resolved': True}], 'target_source_code': lying_src, 'claimed_mechanisms': [{'claim_id': 'multipole', 'required_ast_tokens': ['anisotropic_multipole'], 'forbidden_ast_tokens': []}], 'post_hoc_probe_verdicts': {'G3m': 'PASS'}}), 'mismatch'),
        '' if 'anisotropic_multipole' not in stripped_card['executable_expressions_joined'] else '[stripped card retained docstring claim]',
    ]
    bad = [msg for msg in issues if msg]
    if bad:
        raise AssertionError('Negative controls (rc38 physics redteam/glue) not rejected:\n' + '\n'.join(bad))
    return len(issues)


def run_negative_controls() -> Dict[str, int]:
    """Run every negative-control group; raises AssertionError on the first group with an accepted wrong case."""
    groups = (
        _verify_negative_pairwise_loocv_scale,
        _verify_negative_remediation_bipolar_mesh,
        _verify_negative_topology_clearance_director,
        _verify_negative_dispersion_pencil_coupled,
        _verify_negative_declarative_slots,
        _verify_negative_meta_and_static_gates,
        _verify_negative_rc8_scientific_and_contracts,
        _verify_negative_rc8_nonprefix_gates,
        _verify_negative_rc38_physics_redteam_and_glue,
    )
    counts = {grp.__name__: grp() for grp in groups}
    if sum(counts.values()) < len(groups):
        raise AssertionError(f'Negative-control registry is empty or truncated: {counts}')
    return counts
