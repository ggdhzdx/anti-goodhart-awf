---
name: anti-goodhart-verification
description: Domain-Agnostic Universal 7-Gate Anti-Goodhart & Scientific Computing Verification Engine (66 Automated Gates across 17 Integrated Projects + Self-Hosting Dogfood Audit + Scientific Computing Method Development Pack + Tutor Implementation-Layer Goodhart Countermeasures + Calibrated Scientific Operator Invariant Pack), Pre-Execution AST/Dataflow/Intent/NCC/Pair-Diff Guards, Static -inf Circuit-Breaker for TODO/Stub/NotImplemented/Magic-Numbers/Unused-Vars (G5n), 6-Dimensional Micro-Step Sufficiency & Topological 1-Hop DAG Anchor (G6o), Red-Blue Adversarial Auditor Decoupled Game (G7h), Pairwise Exchange Symmetry & Intra-Group Self-Interaction Exclusion (G5o), Exact Hat-Matrix Leverage LOOCV & Train/Eval Feature Parity (G7i), Euler Scale Homogeneity & Asymmetric Rank-1 Null Zero-Point Calibration (G3j), Autonomous Remediation Closed-Loop & Multi-Candidate Pareto Selector (G6p), Bipolar Sign Reachability & Multi-Source Delta-Method Variance Propagation (G5p), Analytic Force/Gradient vs 4th-Order Richardson Finite-Difference Verifier (G2b), Asymptotic Grid/Step Convergence Order O(h^p) Verifier (G1d), 3D SE(3) + Triclinic PBC Minimum-Image + S_N Permutation Equivariance Verifier (G3i), Physical Matrix Hermiticity/PSD/Detailed-Balance & Cross-Atom Unit Homogeneity Verifier (G5m), Turn-Level Agent Claim Fact-Checker & Command-Receipt Freshness Verifier, Trajectory Fairness & 11-Channel Bypass/Base64-Smuggling Auditor, EvilGenie Cryptographic Harness File Integrity & 3D Categorical Scorer, General Multi-Source & Output-Dependent Metamorphic Testing Engine, BenchJack V1-V8 Evaluator Hackability & Trust-Boundary Scanner, Red-Green Friendly-Fire Regression Gate & Best-of-K Selection Gap Auditor, Jaxtyping Symbolic Algebraic Shape & Variadic Batch/Broadcast Contract Engine, Agent-Guardrails Task Scope/Continuity & Verity Receipt Auditor, Aurite Agent-Verifier Loop/Retry/Tool-Registry/Graph-Cycle/Security/Quality Auditor, ImpossibleBench Conflicting Canary Trap & Anti-Sycophancy Auditor, FalseGreen & PyNose Hollow-Test/Tautological-Assert/Self-Mocking Scanner, Mutmut In-Memory AST Mutation Kill-Rate Engine & Anti-Loose-Tolerance Auditor, Design-by-Contract Input Immutability Snapshot (deal.pure / icontract.snapshot) & CrossHair Adversarial Boundary Fuzzer, SplitGuard BLAKE2b Row-Taint Data-Leakage & Group/Conformer Split Auditor, PitfallsFP Floating-Point Catastrophic Cancellation AST Scanner & Monte Carlo Arithmetic (MCA) Conditioning Auditor, Self-Hosting Zero-Violation Dogfood Auditor (--audit-self / G6n), Second-Order Anti-Collusion Meta-Guard, Information-Asymmetry Boundary Seal (SealedHoldoutCapsule), Anti-Leak Abstract Diagnostic Sanitizer, 3-Zone Tri-State Verdict, Clean-Room Tempdir Sandbox, Risk-Tiered Escalation (Tier-0/1/2), Post-Escape Gate Self-Evolution, and Atomic Operator Capsule Architecture (@scientific_atom Physical-Unit/Symbolic-Shape Contract Bus & AST Call-Graph Auto-DAG atom_manifest.json) for Agent Workflow Foundry (AWF Guard / ag / 7g / anti-goodhart-verification / 防偷懒 / 防作弊 / 七重防伪门禁).
---
# AWF Guard: Universal 7-Gate Anti-Goodhart, Scientific Computing & Tutor Implementation-Goodhart Engine (`skill.anti-goodhart-verification@3.4.0-rc.1`)

## Canonical Engine Location

- **AWF Authoritative Source (`3.4.0-rc.1`)**: `Z:\agent_workflows\components\skills\anti-goodhart-verification\releases\3.4.0-rc.1\source\scripts\awf_universal_anti_goodhart_gates.py` (`/home/zc/agent_workflows/components/skills/anti-goodhart-verification/releases/3.4.0-rc.1/source/scripts/awf_universal_anti_goodhart_gates.py`)
- **Co-Located 66-Gate Self-Test Suite (`3.4.0-rc.1`)**: `Z:\agent_workflows\components\skills\anti-goodhart-verification\releases\3.4.0-rc.1\source\scripts\awf_anti_goodhart_selftest_suite.py`
- **Global Skill Path (Windows)**: `C:\Users\zc\.gemini\config\skills\anti-goodhart-verification\scripts\awf_universal_anti_goodhart_gates.py`
- **Global Skill Path (Cluster Linux)**: `/home/zc/.gemini/config/skills/anti-goodhart-verification/scripts/awf_universal_anti_goodhart_gates.py` (`Z:\.gemini\config\skills\anti-goodhart-verification\scripts\awf_universal_anti_goodhart_gates.py`)

---

## Core Architecture: Twenty-Five Pillars of Anti-Shortcut & Scientific Computing Governance (`66 Automated Gates`)

1. **Pillar 1**: Defense Against the 6 Universal Degenerate Failure Modes (Mode I–VI).
2. **Pillar 2**: The Universal 7-Gate Meta-Protocol (`G1`–`G7`, covering **66 concrete automated sub-gates**).
3. **Pillar 3 (`v1.2.0-rc.1`, from `Nick-is-building/ast-guard`)**: Parameter-Taint Fixed-Point Dataflow, Extensional Enumeration/Dict-Dispatch Detection (with IUPAC Periodic Table & Physical Constant Table exemption), Docstring + Decorator `@scientific_atom(math_contract=...)` Intent Alignment (including `no_exponential_operator` and `no_logarithmic_operator`), `zlib` NCC Test-Overlap, Pair-Mode Complexity Collapse & New-Constant Bypass Audit, and Anti-Harness Tampering.
4. **Pillar 4 (`v1.3.0-rc.1`, from `blasrodri/truth`)**: Turn-Level Agent Claim Fact-Checker against `git diff` + AST Symbols/Constants, Command-Receipt Edit-Freshness & Scope-Narrowing/Zero-Test Gate, 5-State Epistemic Verdict Taxonomy, and Wall-of-Refusals Detector.
5. **Pillar 5 (`v1.4.0-rc.1`, from `islo-labs/reward-hack-bench`)**: 3-Byte-Alignment Base64 & Line-Wrap Obfuscation Scanner (`G5f`), 11-Channel Trajectory Fairness & Bypass Smuggling Auditor (`G6d`), Orthogonal (`static_reward` $\times$ `fairness`) Scorer, and Prompt Attribution Sanitizer.
6. **Pillar 6 (`v1.5.0-rc.1`, from `JonathanGabor/evilgenie_inspect`)**: Cryptographic Harness File Snapshot & Auto-Restore (`HarnessIntegritySnapshot`, `G6e`), AST Direct Test-File Reading & Size-Cutoff Heuristic Fallback Detector (`G5g`), Per-Problem Seeded Deterministic Visible/Holdout Splitter, and 3D Categorical EvilGenie Scorer.
7. **Pillar 7 (`v1.6.0-rc.1`, from `tum-i4/gemtest`)**: General $k$-Source $\to$ $m$-Followup Metamorphic Testing Engine (`G3c`) and Output-Dependent Followup Metamorphic Relations (`G3d`).
8. **Pillar 8 (`v1.7.0-rc.1`, from `benchjack/benchjack`)**: BenchJack V1–V8 Evaluator Hackability & Trust-Boundary Scanner (`G6f`, `G6g`).
9. **Pillar 9 (`v1.8.0-rc.1`, from `rushjais/Goodhart`)**: Red-Green Verifier Hardening Friendly-Fire Regression Gate (`G7d`) & Best-of-K Selection Gap Benchmark (`G7e`).
10. **Pillar 10 (`v1.9.0-rc.1`, from `patrick-kidger/jaxtyping`)**: Jaxtyping Symbolic Algebraic Shape Evaluator (`G3e`) & Variadic Batch/Broadcast Contract Engine (`G3f`).
11. **Pillar 11 (`v1.10.0-rc.1`, from `logi-cmd/agent-guardrails`)**: Task Scope, Continuity, Parallel-Abstraction & Source-Without-Tests Auditor (`G6h`) and Strict Schema-Locked Verity Cryptographic Receipt Validator (`G6i`).
12. **Pillar 12 (`v2.0.0-rc.1`, from `Aurite-ai/agent-verifier`)**: Unbounded Loop/Recursion, Unbounded Retry, Tool-Registry Hallucination & LangGraph Dead-Cycle Auditor (`G5h`) and Zero-Secrets, Insecure SSL/CORS & Swallowed-Exception Auditor (`G5i`).
13. **Pillar 13 (`v2.1.0-rc.1`, from `safety-research/impossiblebench`, ICLR)**: Conflicting Canary Trap, Seeded-Generator-Aware Referential Transparency & Stateful Call-Counter Detector (`G6j`) and Anti-Sycophancy Contradictory Specification Flag (`G7f`).
14. **Pillar 14 (`v2.2.0-rc.1`, from `vinicq/falsegreen` & `JetBrains-Research/PyNose`)**: Hollow-Test & Tautological Assertion AST Scanner (`G6k`) and Zero Self-Mocking & Bogus Mock Assertion Gate (`G6l`).
15. **Pillar 15 (`v2.3.0-rc.1`, from `boxed/mutmut`)**: Clean-Room `importlib` AST Mutation Kill-Rate Engine (`G5j`) and Anti-Loose-Tolerance Inflation Auditor (`G5k`).
16. **Pillar 16 (`v2.4.0-rc.1`, from `Parquery/icontract`, `life4/deal` & `pschanely/CrossHair`)**: Input Immutability Snapshot (`G3g`) and Adversarial Corner-Case Boundary Fuzzer (`G3h`).
17. **Pillar 17 (`v2.5.0-rc.1`, from `Tommasoaiello13/splitguard` & `SE4AIResearch/DataLeakage`)**: Pre-Split Preprocessing AST Scanner (`G6m`) and 16-Byte BLAKE2b Row-Taint & Group/Conformer Split Auditor (`G7g`).
18. **Pillar 18 (`v3.0.0-rc.1`, from `gmarkall/PitfallsFP` & Monte Carlo Arithmetic)**: Floating-Point Anti-Pattern AST Scanner (`G5l`) and Monte Carlo Arithmetic (MCA) & Float32 Precision-Downgrade Conditioning Auditor (`G1c`).
19. **Pillar 19 (`v3.1.0-rc.1`, Self-Hosting Dogfood Integrity Audit)**: Zero-Violation Self-Referential Engine & $\le 160$-Line Capsule Granularity Gate (`audit_engine_self_hosting_integrity`, `G6n_SelfHosting_ZeroViolation_Dogfood_Audit`, `--audit-self`).
20. **Pillar 20 (`v3.2.0-rc.1`, Scientific Computing Method Development Pack)**:
    - **Analytic Force/Gradient vs. 4th-Order Richardson Central Finite-Difference Verifier (`verify_analytic_gradient_finite_difference`, `G2b`)**;
    - **Asymptotic Convergence Order Verifier (`verify_asymptotic_convergence_order`, `G1d`)**;
    - **3D $SE(3)$ Rigid Rotation/Translation, Triclinic PBC Minimum-Image & $S_N$ Permutation Equivariance Verifier (`verify_se3_pbc_and_permutation_equivariance`, `G3i`)**;
    - **Physical Matrix Invariants & Cross-Atom Unit Homogeneity Verifier (`verify_physical_matrix_invariants_and_unit_homogeneity`, `G5m`)**;
    - **Adaptive Runtime Execution Budget Evaluator (`evaluate_adaptive_runtime_budget`)**.
21. **Pillar 21 (`v3.3.0-rc.1`, Tutor Implementation-Layer Goodhart Countermeasures Pack)**:
    - **Static $-\infty$ Circuit-Breaker (`scan_source_for_todo_placeholders_and_magic_numbers`, `G5n`)**: Maps `TODO`/`FIXME`/`PLACEHOLDER`/`STUB` comments, hollow `pass`/`...` function bodies, `raise NotImplementedError`, unused local variables, and unexplained magic float literals directly to `effective_reward = -inf`.
    - **6-Dimensional Micro-Step Sufficiency & Topological 1-Hop Frontier Anchor (`verify_microstep_granularity_and_topological_anchor`, `G6o`)**: Quantitatively enforces step-size sufficiency across line count $L \in [3, 160]$, McCabe complexity $V(G) \le 10$, I/O arity, topological 1-hop lock, MCA conditioning $\kappa \le 10^4$, and $\ge 2$ physical invariant anchors.
    - **Red-Blue Adversarial Decoupled Auditor (`evaluate_red_blue_adversarial_audit`, `G7h`)**: Decouples Blue Builder and Red Auditor payoffs so the Red Auditor only earns positive bounty by exposing simplified surrogate assumptions, fake data, placeholder stubs, or adversarial counterexamples.
22. **Pillar 22 (`v3.4.0-rc.1`, Calibrated Scientific Operator Invariant & Remediation Closed-Loop Pack)**:
    - **Pairwise Kernel Exchange Symmetry & Intra-Group Self-Interaction Exclusion (`verify_pairwise_no_self_interaction_and_symmetry`, `G5o`)**: Verifies $K(A, B) = K(B, A)$ and zero intra-group self-interaction $\mathcal{A}([A, B], \text{group\_ids}=[0, 0]) = 0$.
    - **Exact Hat-Matrix Leverage LOOCV & Train/Eval Feature-Extractor Parity (`verify_loocv_generalization_and_train_eval_parity`, `G7i`)**: Verifies Leave-One-Out Cross-Validation $R^2_{\text{LOOCV}}$ floor, generalization gap, and zero Train/Eval feature-extractor skew.
    - **Euler Scale Homogeneity & Asymmetric Rank-1 Product Null-Model Calibration (`verify_scale_homogeneity_and_rank1_null_calibration`, `G3j`)**: Verifies $f(\lambda x) = \lambda^k f(x)$ and exact zero-point calibration on asymmetric rank-1 independent product distributions $P = p p^T$ across $p \in (0, 1)$.
    - **Autonomous Remediation Closed-Loop, Differential Pair-Audit & Pareto Selector (`verify_remediation_closed_loop_and_pareto_candidates`, `G6p`)**: Enforces autonomous vs. human escalation boundaries, pre/post-fix AST pair-diff anti-watering-down checks, and multi-candidate Pareto ranking.
    - **Bipolar Sign Reachability & Multi-Source Delta-Method Variance Propagation (`verify_bipolar_reachability_and_multisource_variance`, `G5p`)**: Verifies negative/positive regime sign reachability $f(x_{\text{neg}}) < -\epsilon < +\epsilon < f(x_{\text{pos}})$ (catching non-negative quadratic surrogates) and multi-source Delta-method variance propagation $\text{Var}_{\text{tot}} = \text{Var}_{\text{obs}} + \nabla_\theta g^T \Sigma_{\text{ref}} \nabla_\theta g > \text{Var}_{\text{obs}}$.
23. **Pillar 23 (`v1.1.0-rc.1`, from `illyar80/developer-farm`)**: Information-Asymmetry Boundary Seal (`SealedHoldoutCapsule`), Anti-Leak Retry Feedback Sanitizer, 3-Zone Tri-State Verdict, and Clean-Room Tempdir Sandbox.
24. **Pillar 24**: Second-Order Meta-Guard, Tier-0/1/2 Escalation, Dual-Modality & Post-Escape Evolution.
25. **Pillar 25**: Atomic Operator Capsule Granularity (`@scientific_atom`) & AST Call-Graph Auto-DAG (`AtomManifestIndex`).

---

## CLI Quick Reference

```bash
# 1. Run built-in 66-Gate, Scientific Computing Pack & Self-Hosting Dogfood self-test
python /home/zc/agent_workflows/components/skills/anti-goodhart-verification/releases/3.4.0-rc.1/source/scripts/awf_universal_anti_goodhart_gates.py --self-test

# 2. Run Self-Hosting Zero-Violation Dogfood Audit on the engine itself
python /home/zc/agent_workflows/components/skills/anti-goodhart-verification/releases/3.4.0-rc.1/source/scripts/awf_universal_anti_goodhart_gates.py --audit-self
```
